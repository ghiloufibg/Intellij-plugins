Pack de variantes OCR — factures françaises synthétiques

Contenu :
01 nette : PDF texte propre
02 scan gris : rendu niveaux de gris
03 scan bruit : bruit, contraste réduit et léger flou
04 rotation : inclinaison légère
05 tableau complexe : tableau de lignes et colonnes
06 deux pages : facture multipage
07 caractères : accents, symboles et références
08 mise en page : rendu raster avec contraste modifié

Les documents sont conçus pour des tests OCR et utilisent des données synthétiques.
